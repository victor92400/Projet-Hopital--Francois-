/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modèle;

import java.sql.SQLException;
import vue.FenetreJp;
import java.util.ArrayList;
import vue.AffichageConsole;
import controleur.JavaApplication7;
import Modèle.Connexion;
import Modèle.Recherche;
import java.sql.SQLException;
import vue.FenetreJP2;
import vue.FenetreJp;
/**

/**
 *
 * @author solen
 */
public class MiseAJour {
  private final  FenetreJp fen;
  
  public MiseAJour() throws SQLException, ClassNotFoundException
  {
        this.fen = new FenetreJp();
      
  }

   
}
