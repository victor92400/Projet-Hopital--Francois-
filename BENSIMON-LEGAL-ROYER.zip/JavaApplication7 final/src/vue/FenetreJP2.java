/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vue;

/**
 *
 * @author Jean-Pierre Segado /* To change this template, choose Tools |
 * Templates and open the template in the editor.
 */
/*
 * 
 * Librairies importées
 */
import Modèle.Connexion;
import java.awt.event.*;
import java.awt.*;
import java.util.*;
import javax.swing.*;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * Affiche dans la fenetre graphique les champs de tables et les requetes de la
 * BDD
 *
 * @author segado
 */
public class FenetreJP2 extends JFrame implements ActionListener, ItemListener {

    /*
     * Attribut privés : objets de Connexion, AWT et Swing
     * 
     */
    private Connexion maconnexion;

    private final JLabel tab, req, res, lignes, requete1;
    private final JLabel nameECE, passwdECE, loginBDD, passwdBDD, nameBDD, requeteLabel, nomTab_1, nomTab_2, nomTab_3, nomTab_4, nomElement_1, nomElement_2, nomElement_3, nomElement_4;
    private final JTextField nameECETexte, loginBDDTexte, requeteTexte, nameBDDTexte, selectionTexte_1, selectionTexte_2, selectionTexte_3;
    private final JPasswordField passwdECETexte, passwdBDDTexte;
    private final JButton connect, exec_1, exec_2, exec_3, exec_4, local;
    private final java.awt.List listeDeTables, listeDeRequetes, listeDeRequetesMaj;
    private final JTextArea fenetreLignes, fenetreRes;
    private final JPanel p0, p1, nord, p2, p3, p4, south, p5, p6;
    private final JComboBox combo1, combo2, combo3, combo1_1, combo4;

    /**
     * Constructeur qui initialise tous les objets graphiques de la fenetre
     *
     * @throws java.sql.SQLException
     * @throws java.lang.ClassNotFoundException
     */
    public FenetreJP2() throws SQLException, ClassNotFoundException {

        // creation par heritage de la fenetre
        super("Projet d'utilisation de JDBC dans MySQL");
        maconnexion = new Connexion("hopital", "root", "");

        // mise en page (layout) de la fenetre visible
        setLayout(new BorderLayout());
        setBounds(0, 0, 400, 400);
        setResizable(true);

        // creation des boutons
        connect = new JButton("Connexion ECE");
        local = new JButton("Connexion locale");
        exec_1 = new JButton("Executer");
        exec_2 = new JButton("Executer");
        exec_3 = new JButton("Executer");
        exec_4 = new JButton("Executer");

        // creation des listes pour les tables et les requetes
        listeDeTables = new java.awt.List(10, false);
        listeDeRequetes = new java.awt.List(10, false);
        listeDeRequetesMaj = new java.awt.List(10, false);

        // creation des textes
        nameECETexte = new JTextField();
        passwdECETexte = new JPasswordField(8);
        loginBDDTexte = new JTextField();
        passwdBDDTexte = new JPasswordField(8);
        nameBDDTexte = new JTextField();
        fenetreLignes = new JTextArea();
        fenetreRes = new JTextArea();
        requeteTexte = new JTextField();
        selectionTexte_1 = new JTextField();
        selectionTexte_2 = new JTextField();
        selectionTexte_3 = new JTextField();

        // creation des labels
        requete1 = new JLabel("Table avec une entrée", JLabel.CENTER);
                
                
        nomTab_1 = new JLabel("Nom de la table", JLabel.CENTER);
        nomTab_2 = new JLabel("Specialité", JLabel.CENTER);
        nomTab_3 = new JLabel("Nom de la mutuelle", JLabel.CENTER);
        nomTab_4 = new JLabel("Type de rotation", JLabel.CENTER);

        nomElement_1 = new JLabel("A afficher", JLabel.CENTER);
        nomElement_2 = new JLabel("A afficher", JLabel.CENTER);
        nomElement_3 = new JLabel("A afficher", JLabel.CENTER);
        nomElement_4 = new JLabel("A afficher", JLabel.CENTER);

        tab = new JLabel("Tables", JLabel.CENTER);
        lignes = new JLabel("Lignes", JLabel.CENTER);
        req = new JLabel("Requetes de sélection", JLabel.CENTER);
        res = new JLabel("Résultats requête", JLabel.CENTER);
        nameECE = new JLabel("login ECE :", JLabel.CENTER);
        passwdECE = new JLabel("password ECE :", JLabel.CENTER);
        loginBDD = new JLabel("login base :", JLabel.CENTER);
        passwdBDD = new JLabel("password base :", JLabel.CENTER);
        nameBDD = new JLabel("nom base :", JLabel.CENTER);
        requeteLabel = new JLabel("Entrez votre requete de sélection :", JLabel.CENTER);

        combo1 = new JComboBox();
        combo1.setPreferredSize(new Dimension(50, 10));

        maconnexion.tables.forEach((table) -> {
            combo1.addItem(table);
        });

        combo1_1 = new JComboBox();
        combo1_1.setPreferredSize(new Dimension(100, 20));
        /*        combo1.addItem("DOCTEUR");
        combo1.addItem("EMPLOYE");
        combo1.addItem("SOIGNE");
        combo1.addItem("HOSPITALISATION");
        combo1.addItem("CHAMBRE");
        combo1.addItem("INFIRMIER");
        combo1.addItem("SERVICE");
        combo1.addItem("MALADE"); */

        combo2 = new JComboBox();
        combo2.setPreferredSize(new Dimension(100, 20));
        combo2.addItem("REA");
        combo2.addItem("CHG");
        combo2.addItem("CAR");

        combo3 = new JComboBox();
        combo3.setPreferredSize(new Dimension(100, 20));
/*        combo3.addItem("DOCTEUR");
        combo3.addItem("EMPLOYE");
        combo3.addItem("SOIGNE");
        combo3.addItem("HOSPITALISATION");
        combo3.addItem("CHAMBRE");
        combo3.addItem("INFIRMIER");
        combo3.addItem("SERVICE");
        combo3.addItem("MALADE"); */

        combo4 = new JComboBox();
        combo4.setPreferredSize(new Dimension(100, 20));
        combo4.addItem("JOUR");
        combo4.addItem("NUIT");

        // creation des panneaux
        p0 = new JPanel();
        p1 = new JPanel();
        nord = new JPanel();
        p2 = new JPanel();
        p3 = new JPanel();

        south = new JPanel();
        p4 = new JPanel();
        p5 = new JPanel();
        p6 = new JPanel();

        // mise en page des panneaux
        p0.setLayout(new GridLayout(1, 11));
        p1.setLayout(new GridLayout(1, 4));
        nord.setLayout(new GridLayout(2, 1));
        p2.setLayout(new GridLayout(1, 4));
        p3.setLayout(new GridLayout(1, 5));

        p4.setLayout(new GridLayout(1, 5));
        p5.setLayout(new GridLayout(1, 5));
        p6.setLayout(new GridLayout(1, 5));
        south.setLayout(new GridLayout(4, 1));

        // ajout des objets graphqiues dans les panneaux
        p0.add(nameECE);
        p0.add(nameECETexte);
        p0.add(passwdECE);
        p0.add(passwdECETexte);
        p0.add(loginBDD);
        p0.add(loginBDDTexte);
        p0.add(passwdBDD);
        p0.add(passwdBDDTexte);
        p0.add(connect);
        p0.add(nameBDD);
        p0.add(nameBDDTexte);
        p0.add(local);
        p1.add(tab);
        p1.add(lignes);
        p1.add(req);
        p1.add(res);

        nord.add(p0);
        nord.add(p1);

        p2.add(listeDeTables);
        p2.add(fenetreLignes);
        p2.add(listeDeRequetes);
        p2.add(fenetreRes);
        
        p3.add(requete1);
        p3.add(nomTab_1);
        p3.add(combo1);
        p3.add(nomElement_1);
        p3.add(combo1_1);
//        p3.add(selectionTexte_1);

        p3.add(exec_1);

        p4.add(nomTab_2);
        p4.add(combo2);
        p4.add(new JPanel());
        p4.add(new JPanel());
        //p4.add(nomElement_2);
        //p4.add(selectionTexte_2);

        p4.add(exec_2);

        p5.add(nomTab_3);
        p5.add(combo3);
        p5.add(new JPanel());
        p5.add(new JPanel());
        //p5.add(nomElement_3);
        //p5.add(selectionTexte_3);

        p5.add(exec_3);

        p6.add(nomTab_4);
        p6.add(combo4);
        p6.add(new JPanel());
        p6.add(new JPanel());

        p6.add(exec_4);
        
        south.add(p3);
        south.add(p4);
        south.add(p5);
        south.add(p6);

        // ajout des listeners
        connect.addActionListener(this);
        exec_1.addActionListener(this);
        exec_2.addActionListener(this);
        exec_3.addActionListener(this);
        exec_4.addActionListener(this);
        local.addActionListener(this);
        nameECETexte.addActionListener(this);
        passwdECETexte.addActionListener(this);
        loginBDDTexte.addActionListener(this);
        passwdBDDTexte.addActionListener(this);
        listeDeTables.addItemListener(this);
        listeDeRequetes.addItemListener(this);
        selectionTexte_1.addActionListener(this);
        selectionTexte_2.addActionListener(this);
        selectionTexte_3.addActionListener(this);
        combo1.addActionListener(this);

        // couleurs des objets graphiques
        tab.setBackground(Color.MAGENTA);
        lignes.setBackground(Color.MAGENTA);
        req.setBackground(Color.MAGENTA);
        res.setBackground(Color.MAGENTA);
        listeDeTables.setBackground(Color.CYAN);
        fenetreLignes.setBackground(Color.WHITE);
        listeDeRequetes.setBackground(Color.GREEN);
        fenetreRes.setBackground(Color.WHITE);
        p1.setBackground(Color.LIGHT_GRAY);

        // disposition geographique des panneaux
        add("North", nord);
        add("Center", p2);
//        add("South", p4);
//        add("South", p3);
        add("South", south);
        setVisible(true);

        // pour fermer la fenetre
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent evt) {
                System.exit(0); // tout fermer												System.exit(0); // tout fermer
            }
        });
    }

    /**
     * Méthode privée qui initialise la liste des tables
     */
    public void remplirTables() {
        maconnexion.ajouterTable("CHAMBRE");
        maconnexion.ajouterTable("MALADE");
        maconnexion.ajouterTable("DOCTEUR");
        maconnexion.ajouterTable("EMPLOYE");
        maconnexion.ajouterTable("INFIRMIER");
        maconnexion.ajouterTable("HOSPITALISATION");
        maconnexion.ajouterTable("SERVICE");
        maconnexion.ajouterTable("SOIGNE");

    }

    /**
     * Méthode privée qui initialise la liste des requetes de selection
     */
    public void remplirRequetes() {
        maconnexion.ajouterRequete("SELECT nom, prenom FROM malade WHERE mutuelle='MAAF';"); //R1
        maconnexion.ajouterRequete("SELECT nom, prenom FROM employe WHERE numero IN (SELECT numero FROM infirmier WHERE rotation='NUIT')"); //R2
        maconnexion.ajouterRequete("SELECT service.nom AS serv, batiment, prenom, employe.nom AS noom, specialite FROM service INNER JOIN employe ON service.directeur = employe.numero INNER JOIN docteur ON  docteur.numero = employe.numero"); //R3
        maconnexion.ajouterRequete("SELECT nom, prenom, mutuelle FROM malade WHERE mutuelle LIKE 'MN%'"); //R4
        maconnexion.ajouterRequete("SELECT code_service, AVG(salaire) FROM infirmier GROUP BY code_service"); //R5
        maconnexion.ajouterRequete("SELECT code_service, AVG(nb_lits) FROM chambre GROUP BY code_service"); //R6
        //maconnexion.ajouterRequete("SELECT COUNT(no_docteur) FROM soigne"); //R7
        maconnexion.ajouterRequete("SELECT code_service, COUNT(DISTINCT numero)/(SELECT COUNT(DISTINCT no_malade) FROM hospitalisation WHERE code_service='CAR') FROM infirmier WHERE code_service='CAR'"); //R8.1 (améliorer pour généraliser à tous les services)
        maconnexion.ajouterRequete("SELECT code_service, COUNT(DISTINCT numero)/(SELECT COUNT(DISTINCT no_malade) FROM hospitalisation WHERE code_service='CHG') FROM infirmier WHERE code_service='CHG'"); //R8.2
        maconnexion.ajouterRequete("SELECT code_service, COUNT(DISTINCT numero)/(SELECT COUNT(DISTINCT no_malade) FROM hospitalisation WHERE code_service='REA') FROM infirmier WHERE code_service='REA'"); //R8.3
        maconnexion.ajouterRequete("SELECT nom, prenom FROM employe WHERE EXISTS (SELECT numero FROM docteur)"); //R9
        maconnexion.ajouterRequete("SELECT nom, prenom, no_docteur FROM employe, soigne WHERE no_docteur=no_malade IS NULL ");//R10
        maconnexion.ajouterRequete("SELECT nom, prenom FROM employe WHERE numero IN (SELECT docteur.numero from docteur inner join soigne on docteur.numero=soigne.no_docteur group by docteur.numero)");
//String mutuelle="LMDE"; 
    }

    /**
     * Méthode privée qui initialise la liste des requetes de MAJ
     */
    private void remplirRequetesMaj() throws SQLException {
        // Requêtes d'insertion
        maconnexion.ajouterRequeteMaj("INSERT INTO DOCTEUR(NUMERO, SPECIALITE) VALUES ('1776' ,'Radiologue');");
//        maconnexion.executeUpdate("INSERT INTO DOCTEUR(NUMERO, SPECIALITE) VALUES ('176' ,'Radiologue');");
        //   maconnexion.executeUpdate("INSERT INTO DOCTEUR(NUMERO, SPECIALITE) VALUES ('170' ,'Radiologue');");
        // maconnexion.ajouterRequeteMaj("INSERT INTO Dept (deptno,dname,loc) VALUES (50,'ECE','Paris');");

        // Requêtes de modification
        // maconnexion.ajouterRequeteMaj("UPDATE Dept SET loc='Eiffel' WHERE loc='Paris';");
        // Requêtes de suppression
        //maconnexion.ajouterRequeteMaj("DELETE FROM Dept WHERE loc='Eiffel';");
    }

    /**
     *
     * Afficher les tables
     */
    public void afficherTables() {
        for (String table : maconnexion.tables) {
            listeDeTables.add(table);
        }
    }

    /**
     *
     * Afficher les lignes de la table sélectionnée
     */
    public void afficherLignes(String nomTable) {
        try {
            ArrayList<String> liste;

            // effacer les résultats
            fenetreLignes.removeAll();

            // recupérér les résultats de la table selectionnee
            liste = maconnexion.remplirChampsTable(nomTable);

            // afficher les champs de la table selectionnee 
            fenetreLignes.setText("");
            for (String liste1 : liste) {
                fenetreLignes.append(liste1);
            }

            // recuperer la liste de la table sélectionnée
            String requeteSelectionnee = "select * from " + nomTable + ";";
            liste = maconnexion.remplirChampsRequete(requeteSelectionnee);

            // afficher les lignes de la requete selectionnee a partir de la liste
            for (String liste1 : liste) {
                fenetreLignes.append(liste1);
            }

        } catch (SQLException e) {
            // afficher l'erreur dans les résultats
            fenetreRes.setText("");
            fenetreRes.append("Echec table SQL");
            e.printStackTrace();

        }
    }

    public void miseAJourCombosTables() {
        combo1.removeAllItems();

        maconnexion.tables.forEach((table) -> {
            combo1.addItem(table);
        });

        combo3.removeAllItems();
        try {
            for (String tmpString : (ArrayList<String>) maconnexion.remplirChampsRequete("SELECT DISTINCT mutuelle FROM malade;")) {
                combo3.addItem(tmpString);
            }
        } catch (SQLException e) {
            System.out.println("Connexion echouee : probleme SQL");
            e.printStackTrace();
        }
    }

    public void miseAJourCombos(JComboBox comboSource, JComboBox comboCible) {
        combo1_1.removeAllItems();

        try {
            String tmpString = (String) maconnexion.remplirChampsTable(combo1.getSelectedItem().toString()).get(0);
            ArrayList<String> columnsNames = new ArrayList<String>(Arrays.asList(tmpString.split(" ")));
            columnsNames.removeAll(Arrays.asList("", "\n", null));

            for (String column : columnsNames) {
                combo1_1.addItem(column);
            }
        } catch (SQLException e) {
            System.out.println("Connexion echouee : probleme SQL");
            e.printStackTrace();
        }
    }

    /**
     *
     * Afficher les requetes de selection et de MAJ dans la fenetre
     */
    public void afficherRequetes() {
        maconnexion.requetes.forEach((requete) -> {
            listeDeRequetes.add(requete);
        });

    }

    /*  public void executer() throws SQLException
    {
        for (String requete: maconnexion.requetesMaj)
        {
            listeDeRequetesMaj.add(requete);
            maconnexion.executeUpdate("INSERT INTO DOCTEUR(NUMERO, SPECIALITE) VALUES ('173' ,'Radiologue');");
        }
    }*/
    public ArrayList<String> afficherRes(String requeteSelectionnee) throws SQLException {
        ArrayList<String> liste = null;
        try {

            // effacer les résultats
            fenetreRes.removeAll();

            // recupérér les résultats de la requete selectionnee
            liste = maconnexion.remplirChampsRequete(requeteSelectionnee);

            // afficher les lignes de la requete selectionnee a partir de la liste
            fenetreRes.setText("");
            for (String liste1 : liste) {
                fenetreRes.append(liste1);
            }
        } catch (SQLException e) {
            // afficher l'erreur dans les résultats
            fenetreRes.setText("");
            fenetreRes.append("Echec requete SQL");
        }
        return liste;
    }

    /**
     *
     * Afficher et retourner les résultats de la requete sélectionnée
     *
     * @param requeteSelectionnee
     */
    /**
     *
     * Pour gerer les actions sur les boutons on utilise la fonction
     * actionPerformed
     *
     * @param evt
     */
    @Override
    @SuppressWarnings("CallToThreadDumpStack")
    public void actionPerformed(ActionEvent evt) {
        Object source = evt.getSource();

        // tester cas de la commande evenementielle
        if (source == connect) {
            ArrayList<String> liste;
            String passwdECEString = new String(passwdECETexte.getPassword());
            String passwdBDDString = new String(passwdBDDTexte.getPassword());
            try {
                try {
                    // tentative de connexion si les 4 attributs sont remplis
                    maconnexion = new Connexion("hopital", "root", "");

                    // effacer les listes de tables et de requêtes
                    listeDeTables.removeAll();
                    listeDeRequetes.removeAll();

                    // initialisation de la liste des requetes de selection et de MAJ
                    remplirTables();
                    miseAJourCombosTables();
                    remplirRequetes();
                    remplirRequetesMaj();

                    // afficher la liste de tables et des requetes
                    afficherTables();
                    afficherRequetes();
                    //  executer();

                    // se positionner sur la première table et requête de selection
                    listeDeTables.select(0);
                    listeDeRequetes.select(0);

                    // afficher les champs de la table sélectionnée
                    String nomTable = listeDeTables.getSelectedItem();

                    // recuperer les lignes de la table selectionnee
                    afficherLignes(nomTable);

                    // recuperer la liste des lignes de la requete selectionnee
                    String requeteSelectionnee = listeDeRequetes.getSelectedItem();

                    // afficher les résultats de la requete selectionnee
                    afficherRes(requeteSelectionnee);
                } catch (ClassNotFoundException cnfe) {
                    System.out.println("Connexion echouee : probleme de classe");
                    cnfe.printStackTrace();
                }
            } catch (SQLException e) {
                System.out.println("Connexion echouee : probleme SQL");
                e.printStackTrace();
            }
        } else if (source == local) {
            ArrayList<String> liste;
            try {
                try {
                    // tentative de connexion si les 4 attributs sont remplis
                    maconnexion = new Connexion("hoptial", "root", " ");
                    // effacer les listes de tables et de requêtes
                    listeDeTables.removeAll();
                    listeDeRequetes.removeAll();

                    // initialisation de la liste des requetes de selection et de MAJ
                    remplirTables();
                    //remplirRequetes();
                    remplirRequetesMaj();

                    // afficher la liste de tables et des requetes
                    afficherTables();
                    afficherRequetes();

                    // se positionner sur la première table et requête de selection
                    listeDeTables.select(0);
                    listeDeRequetes.select(0);

                    // afficher les champs de la table sélectionnée
                    String nomTable = listeDeTables.getSelectedItem();

                    // recuperer les lignes de la table selectionnee
                    afficherLignes(nomTable);

                    // recuperer la liste des lignes de la requete selectionnee
                    String requeteSelectionnee = listeDeRequetes.getSelectedItem();

                    // afficher les résultats de la requete selectionnee
                    afficherRes(requeteSelectionnee);
                } catch (ClassNotFoundException cnfe) {
                    System.out.println("Connexion echouee : probleme de classe");
                    cnfe.printStackTrace();
                }
            } catch (SQLException e) {
                System.out.println("Connexion echouee : probleme SQL");
                e.printStackTrace();
            }
        } else if (source == exec_1) {
            //      String requeteSelectionnee = requeteTexte.getText(); // récupérer le texte de la requête
            String requeteSelectionnee = "Select " + combo1_1.getSelectedItem().toString() + " From " + combo1.getSelectedItem().toString() + ";";
            // effacer les résultats
            fenetreRes.removeAll();

            try {
                // afficher les résultats de la requete selectionnee
                if (afficherRes(requeteSelectionnee) != null) {
                    maconnexion.ajouterRequete(requeteSelectionnee);
                    listeDeRequetes.removeAll();
                    afficherRequetes();
                }
            } catch (SQLException ex) {
            }

        } else if (source == exec_2) {
//      maconnexion.ajouterRequete();
            String requeteSelectionnee = "SELECT code_service, COUNT(DISTINCT numero)/(SELECT COUNT(DISTINCT no_malade) FROM hospitalisation WHERE code_service='" + combo2.getSelectedItem().toString() + "') FROM infirmier WHERE code_service='" + combo2.getSelectedItem().toString() + "';";
            // effacer les résultats
            fenetreRes.removeAll();

            try {
                // afficher les résultats de la requete selectionnee
                if (afficherRes(requeteSelectionnee) != null) {
                    maconnexion.ajouterRequete(requeteSelectionnee);
                    listeDeRequetes.removeAll();
                    afficherRequetes();
                }
            } catch (SQLException ex) {
            }
        } else if (source == exec_3) {
            String requeteSelectionnee = "SELECT nom, prenom FROM malade WHERE mutuelle='" + combo3.getSelectedItem().toString().trim() + "';";
            // effacer les résultats
            fenetreRes.removeAll();
            
            

            try {
                // afficher les résultats de la requete selectionnee
                if (afficherRes(requeteSelectionnee) != null) {
                    maconnexion.ajouterRequete(requeteSelectionnee);
                    listeDeRequetes.removeAll();
                    afficherRequetes();
                }
            } catch (SQLException ex) {
            }
        }else if (source == exec_4) {
            
            String requeteSelectionnee = "SELECT prenom, nom FROM employe WHERE numero IN (SELECT numero FROM infirmier WHERE rotation='" + combo4.getSelectedItem().toString().trim() + "') ORDER BY employe.nom;";
            // effacer les résultats
            fenetreRes.removeAll();
            
            

            try {
                // afficher les résultats de la requete selectionnee
                if (afficherRes(requeteSelectionnee) != null) {
                    maconnexion.ajouterRequete(requeteSelectionnee);
                    listeDeRequetes.removeAll();
                    afficherRequetes();
                }
            } catch (SQLException ex) {
            }
        } else if (source == combo1) {
            miseAJourCombos(combo1, combo1_1);
        }
    }

    /**
     *
     * Pour gerer les actions sur items d'une liste on utilise la methode
     * itemStateChanged
     *
     * @param evt
     */
    @SuppressWarnings("CallToThreadDumpStack")
    @Override
    public void itemStateChanged(ItemEvent evt) {
        // sélection d'une requete et afficher ses résultats
        if (evt.getSource() == listeDeRequetes) {
            // recuperer la liste des lignes de la requete selectionnee
            String requeteSelectionnee = listeDeRequetes.getSelectedItem();
            try {
                afficherRes(requeteSelectionnee);
            } catch (SQLException ex) {
                Logger.getLogger(Fenetre.class.getName()).log(Level.SEVERE, null, ex);
            }
        } else if (evt.getSource() == listeDeTables) {
            // afficher les lignes de la table sélectionnée
            String nomTable = listeDeTables.getSelectedItem();
            afficherLignes(nomTable);
        }
    }
}
