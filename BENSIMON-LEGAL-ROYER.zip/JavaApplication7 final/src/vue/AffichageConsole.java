/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vue;

import java.util.ArrayList;
//import package modèle;

/**
 *
 * @author solen
 */
public class AffichageConsole {
    public void menu()
    {
        int choix=0;
        switch(choix)
        {
            //case 1: affichageRequete();
        }
    }
    
    public void affichageRequete(ArrayList<String>liste){
        
    System.out.println(liste);
}
    
}
