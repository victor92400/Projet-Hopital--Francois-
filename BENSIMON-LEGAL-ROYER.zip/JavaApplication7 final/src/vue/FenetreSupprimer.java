/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vue;

import Modèle.Connexion;
import java.awt.event.*;
import java.awt.*;
import java.util.*;
import javax.swing.*;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author solen
 */
public class FenetreSupprimer extends JFrame implements ActionListener, ItemListener {
        private final JPasswordField passwdECETexte, passwdBDDTexte;
    private static Modèle.Connexion maconnexion;
    
     final JLabel nameECE, passwdECE, loginBDD, passwdBDD, nameBDD,numero;
       private final JTextField  nameECETexte, loginBDDTexte;
         private final JButton connect, exec, local;
   
      private final JPanel p0, p1, nord, p2, pchoix;
        private final JComboBox combo1;
         private final JTextField   selecNumero, nameBDDTexte;
        
     
          static Scanner in = new Scanner(System.in);
    private final JLabel choix;

           public FenetreSupprimer() throws SQLException, ClassNotFoundException{
               
                super("Projet d'utilisation de JDBC dans MySQL");
        maconnexion = new Modèle.Connexion("hopital","root","");

        // mise en page (Gridyout) de la fenetre visible
        setLayout(new BorderLayout());
        setBounds(0, 0, 400, 400);
        setResizable(true);

        // creation des boutons
        connect = new JButton("Connexion ECE");
        local = new JButton("Connexion locale");
        exec = new JButton("Executer");
        
         // creation des textes
         
        nameECETexte = new JTextField();
      nameECE = new JLabel("login ECE :", JLabel.CENTER);
        passwdECE = new JLabel("password ECE :", JLabel.CENTER);
        loginBDD = new JLabel("login base :", JLabel.CENTER);
        passwdBDD = new JLabel("password base :", JLabel.CENTER);
        nameBDD = new JLabel("nom base :", JLabel.CENTER);
        numero=new JLabel("Veuiller rentrer le numero à supprimer no_chambre pour "
                + "la table chambre\n           numero pour les tables docteur, employe et infirmier\n     "
                + "no_malade pour les table malade et hospitalisation          "+"\n"
                + "le code pour la table service :", JLabel.CENTER);
      
        combo1= new JComboBox();
          combo1.setPreferredSize(new Dimension(100, 20));
    combo1.addItem("DOCTEUR");
    combo1.addItem("EMPLOYE");
    combo1.addItem("SOIGNE");
    combo1.addItem("HOSPITALISATION");
    combo1.addItem("CHAMBRE");
    combo1.addItem("INFIRMIER");
    combo1.addItem("SERVICE");
    combo1.addItem("MALADE");
    
    
    connect.addActionListener(this);
        exec.addActionListener(this);
        local.addActionListener(this);
        nameECETexte.addActionListener(this);
    


        choix= new JLabel("Veuillez Choisir la table dans laquelle vous souhaitez supprimer:", JLabel.CENTER);
        loginBDDTexte = new JTextField();
        passwdBDDTexte = new JPasswordField(8);
        nameBDDTexte = new JTextField();

        selecNumero = new JTextField();
        passwdECETexte = new JPasswordField(8);
          p0 = new JPanel();
        p1 = new JPanel();
        nord = new JPanel();
        p2 = new JPanel();
        pchoix=new JPanel();
        
        

        p0.setLayout(new GridLayout(1, 7));
       
        p1.setLayout(new GridLayout(1, 3));
        nord.setLayout(new GridLayout(2, 1));
        p2.setLayout(new GridLayout(1,2 ));
        
                 pchoix.setLayout(new GridLayout(1, 2));
                 
                 
                       p0.add(nameECE);
        p0.add(nameECETexte);
        p0.add(passwdECE);
        p0.add(passwdECETexte);
        p0.add(loginBDD);
        p0.add(loginBDDTexte);
        p0.add(passwdBDD);
        p0.add(passwdBDDTexte);
        p0.add(connect);
        p0.add(nameBDD);
        p0.add(nameBDDTexte);
        p0.add(local);
        p2.add(numero);
        p2.add(selecNumero);
        
        pchoix.add(choix);
       pchoix.add(combo1);
       pchoix.add(exec);
        
        nord.add("North", p0);
        nord.add("North", p1);
        
         add("North",nord);
        add("West", p2);
        add("South", pchoix);
       
 
                setVisible(true);




        // pour fermer la fenetre
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent evt) {
                System.exit(0); // tout fermer												System.exit(0); // tout fermer
            }
        });
           }
           
        
    
    public void SupprimerChambre()
    {
        
            String query="DELETE FROM CHAMBRE WHERE no_chambre='"+selecNumero.getText()+"';";
            maconnexion.ajouterRequeteMaj(query);
             try{
         maconnexion.executeUpdate(query);
        
        } catch (SQLException ex) {
            Logger.getLogger(FenetreJp.class.getName()).log(Level.SEVERE, null, ex);
        }
            
    }
        
    
    public  void SupprimerDocteur()
    {
        
            
            String query="DELETE FROM DOCTEUR WHERE numero='"+selecNumero.getText()+"';";
            maconnexion.ajouterRequeteMaj(query);
             try{
         maconnexion.executeUpdate(query);
        
        } catch (SQLException ex) {
            Logger.getLogger(FenetreJp.class.getName()).log(Level.SEVERE, null, ex);
        }
            

    }

    
    

    public void SupprimerEmploye()
    {
        
            
            String query="DELETE FROM EMPLOYE WHERE numero='"+selecNumero.getText()+"';";
            maconnexion.ajouterRequeteMaj(query);
             try{
         maconnexion.executeUpdate(query);
        
        } catch (SQLException ex) {
            Logger.getLogger(FenetreJp.class.getName()).log(Level.SEVERE, null, ex);
        }
            
    }

    
    public  void SupprimerHospitalisation()
    {
        
         
           String query="DELETE FROM HOSPITALISATION WHERE no_malade='"+selecNumero.getText()+"';";
            maconnexion.ajouterRequeteMaj(query);
            
               try{
         maconnexion.executeUpdate(query);
        
        } catch (SQLException ex) {
            Logger.getLogger(FenetreJp.class.getName()).log(Level.SEVERE, null, ex);
        }
            
            
    }
         
    
  
    public void SupprimerInfirmier()
    {
        
        
            String query="DELETE FROM INFIRMIER WHERE numero='"+selecNumero.getText()+"';";
            maconnexion.ajouterRequeteMaj(query);
              try{
         maconnexion.executeUpdate(query);
        
        } catch (SQLException ex) {
            Logger.getLogger(FenetreJp.class.getName()).log(Level.SEVERE, null, ex);
        }
            
            
    }
        
  
    
    public void SupprimerService()
    {
        
            
            String query="DELETE FROM SERVICE WHERE code='"+selecNumero.getText()+"' ;";
            maconnexion.ajouterRequeteMaj(query);
             try{
         maconnexion.executeUpdate(query);
        
        } catch (SQLException ex) {
            Logger.getLogger(FenetreJp.class.getName()).log(Level.SEVERE, null, ex);
        }
            
            
    }
        
    public void SupprimerMalade()
    {
        
            
            String query="DELETE FROM MALADE WHERE numero='"+selecNumero.getText()+"' ;";
            maconnexion.ajouterRequeteMaj(query);
             try{
         maconnexion.executeUpdate(query);
        
        } catch (SQLException ex) {
            Logger.getLogger(FenetreJp.class.getName()).log(Level.SEVERE, null, ex);
        }
            
            
    }
        
   
  
    
        

    public  void SupprimerSoigne()
    {
        
            
            String query="DELETE FROM SOIGNE WHERE no_malade='"+selecNumero.getText()+"' ;";/////////////////////////
            maconnexion.ajouterRequeteMaj(query);
             try{
         maconnexion.executeUpdate(query);
        
        } catch (SQLException ex) {
            Logger.getLogger(FenetreJp.class.getName()).log(Level.SEVERE, null, ex);
        }
            
    }
        
   
    public void actionPerformed(ActionEvent evt) {
        Object source = evt.getSource();

        // tester cas de la commande evenementielle
        if (source == connect) {
     
            try {
                try {
                    
                    // tentative de connexion si les 4 attributs sont remplis
                    maconnexion = new Connexion("hopital","root","");
                 

              
                } catch (ClassNotFoundException cnfe) {
                    System.out.println("Connexion echouee : probleme de classe");
                    cnfe.printStackTrace();
                }
            } catch (SQLException e) {
                System.out.println("Connexion echouee : probleme SQL");
                e.printStackTrace();
            }
        
            }
         if (source == exec) {
            if(combo1.getSelectedItem().toString()=="SOIGNE")
            {
            
              SupprimerSoigne();
            }
            else if(combo1.getSelectedItem().toString()=="MALADE")
            {
               SupprimerMalade();
            }
              else  if(combo1.getSelectedItem().toString()=="DOCTEUR")
            {
              SupprimerDocteur();
            }
               else  if(combo1.getSelectedItem().toString()=="EMPLOYE")
            {
             SupprimerEmploye();
            }
             else if(combo1.getSelectedItem().toString()=="HOSPITALISATION")
            {
               SupprimerHospitalisation();
            }
               else if(combo1.getSelectedItem().toString()=="SERVICE")
            {
              SupprimerService();
            }
             else if(combo1.getSelectedItem().toString()=="CHAMBRE")
            {
              SupprimerChambre();
            }
               else if(combo1.getSelectedItem().toString()=="INFIRMIER")
            {
              SupprimerInfirmier();
            }
         
        }
    }

    @Override
    public void itemStateChanged(ItemEvent ie) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
